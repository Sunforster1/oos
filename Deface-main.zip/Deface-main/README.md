# B012ED deface

[![chat-bored](https://img.shields.io/badge/endpoint?url=https://b012ed.github.io/chat-B012ED.json&style=?style=for-the-badge&logo=steam)](https://b012ed.github.io/chat.html)

[![YouTube](https://img.shields.io/badge/endpoint?url=https://b012ed.github.io/B012ED.json&style=?style=for-the-badge&logo=youtube)](https://www.youtube.com/channel/UCIqT1hHplli4XvJj7ZUEMzA) 

[![Tools-bored](https://img.shields.io/badge/endpoint?url=https://b012ed.github.io/B012ED-Tools.json&style=?style=for-the-badge&logo=appveyor)](https://www.studypool.com/notebank/search?notebank_qs=b012ed&notebank_qs_university=)

What is B012ED deface tools?<br>
B012ED deface is a tool for defacing dozens or hundreds of sites at once,depending on the number
of sites that have been determined by you, this is not dangerous, and this is only the file upload method<br>

**how to install and usage:**

**Termux:**
* `pkg install python2`
* `pip2 install requests`
* `pkg install git`
* `git clone https://github.com/B012ED/deface.git`
* `cd deface`
* `python2 def.py`

**Linux:**
* `apt-get install python2`
* `apt-get install python2-pip`
* `pip install requests`
* `apt-get install git`
* `git clone https://github.com/B012ED/deface.git`
* `cd deface`
* `python def.py`

**NOTE:** before using this tool, put your deface script with the def.py file, edit the file 'target.txt' and enter the target url


